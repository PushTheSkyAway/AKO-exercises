#include<stdio.h>




int odejmij(int ** x);


int main()
	{
		int x, wynik;

		int a;
		int* p = &a;
		

		scanf_s("%d", &a);
		wynik = a;
		printf("Liczba: %d, x-1: %d", wynik, odejmij(&p));
		
		
		return 0;
	}



