#include<stdio.h>


int szukaj4_max(int a, int b, int c, int d);




int main()
	{
		int x, y, z,q, wynik;
		printf("\nProsz� poda� trzy liczby ca�kowite ze znakiem: ");
		scanf_s("%d %d %d %d", &x, &y, &z,&q, 32);
		wynik = szukaj4_max(x, y, z, q);
		printf("\nSpo�r�d podanych liczb %d, %d, %d %d, liczba %d jest najwi�ksza\n", x, y, z, q, wynik);
		
		return 0;
	}



