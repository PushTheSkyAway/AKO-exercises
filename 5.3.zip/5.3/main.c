#include <stdio.h>

void suma(char *A, char *B, char *wynik);
int main()
{

	char liczby_A[16] = { 1, -127, -126, -125, -124, -123, -122,
	-121, 120, 121, 122, 123, 124, 125, 126, 127 };
	char liczby_B[16] = { -3, -3, -3, -3, -3, -3, -3, -3,
	3, 3, 3, 3, 3, 3, 3, 3 };
	char wynik[16];

	suma(liczby_A, liczby_B, wynik);
	
	for (int i = 0; i < 16; i++) {
		printf("%i ",wynik[i]);
	}


	return 0;
}