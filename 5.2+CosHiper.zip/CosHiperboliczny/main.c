#include <stdio.h>

float nowy_exp(float x);
int main()
{
		
	float x;
	printf("Podaj x: \n");
	scanf_s("%f", &x);
	x = nowy_exp(2);
	
	printf("%f", x);



	return 0;
}