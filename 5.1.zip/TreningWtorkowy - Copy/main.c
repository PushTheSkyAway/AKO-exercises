#include <stdio.h>

float srednia_harm(float * tablica, unsigned int n);

int main()
{
	float tab[5];

	printf("Podaj 5 liczb: \n");
	for(int i=0;i<5;i++)
		scanf_s("%f", &tab[i]);




	float x = srednia_harm(tab,5 );

	printf("%f", x);




	return 0;
}