#include <stdio.h>

void suma(char *A, char *B, char *wynik);

void int2float(int * calkowite, float * zmienno_przec);

void pm_jeden(float * tab);

int main()
{

	char liczby_A[16] = { 1, -127, -126, -125, -124, -123, -122,
	-121, 120, 121, 122, 123, 124, 125, 126, 127 };
	char liczby_B[16] = { -3, -3, -3, -3, -3, -3, -3, -3,
	3, 3, 3, 3, 3, 3, 3, 3 };
	char wynik[16];

	suma(liczby_A, liczby_B, wynik);
	printf("Zadanie 5.3\n");
	for (int i = 0; i < 16; i++) {
		printf("%i ",wynik[i]);
	}

	int ints[2] = { 5, 13 };
	float floats[4];

	int2float(ints, floats);
	printf("\n\nZadanie 5.4 \n");
	for (int i = 0; i < 2; i++) {
		printf("%f ", floats[i]);
	}


	printf("\n\nZadanie 5.5 \n");

	float tablica[4] = { 27.5,143.57,2100.0, -3.51 };
	printf("\n%f %f %f %f", tablica[0],
		tablica[1], tablica[2], tablica[3]);
	pm_jeden(tablica);
	printf("\n%f %f %f %f", tablica[0],
		tablica[1], tablica[2], tablica[3]);





	return 0;
}