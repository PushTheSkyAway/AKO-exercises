#include<stdio.h>




int przeciwna(int * x);


int main()
	{
		int x, wynik;
		scanf_s("%d", &x);
		wynik = x;
		printf("Liczba: %d, Przeciwna: %d", wynik, przeciwna(&x));
		
		
		return 0;
	}



