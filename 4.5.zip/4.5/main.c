#include <stdio.h>
extern __int64 suma_siedmiu_liczb(__int64 v1, __int64 v2, __int64
	v3, __int64 v4, __int64 v5, __int64 v6, __int64 v7);
int main()
{
	
	__int64 v1, v2, v3, v4, v5, v6, v7;
	v1 = 1000;
	v2 = 100;
	v3 = 10;
	v4 = 1;
	v5 = 10000;
	v6 = 100000;
	v7 = 1000000;
	
	__int64 suma = suma_siedmiu_liczb(v1, v2, v3, v4, v5, v6, v7);
	printf("\nSuma wynosi %i", suma);
	_getch();
	return 0;
}