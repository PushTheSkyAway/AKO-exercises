#include <stdio.h> 
void przestaw(int tab[], int n);
int main()
{
	int n;

	
	scanf_s("%d", &n);
	int *arr = malloc(sizeof(int) * n);
	for (int i = 0; i < n; ++i) {
		
		scanf_s("%d", &arr[i]);
	}
	for (int i = 0; i < n - 1; i++) {
		przestaw(arr, n - i);
	}
	printf("\nWynik\n");
	for (int i = 0; i < n; ++i) {
		printf("\n%d", arr[i]);
	}
	free(arr);
	return 0;
}